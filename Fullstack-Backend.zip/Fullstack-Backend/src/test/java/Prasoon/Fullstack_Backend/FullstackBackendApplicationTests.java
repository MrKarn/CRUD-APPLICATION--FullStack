package Prasoon.Fullstack_Backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullstackBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
